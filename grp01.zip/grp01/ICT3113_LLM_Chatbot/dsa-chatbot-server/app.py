import sqlite3
import subprocess
from uuid import uuid4

from flask import Flask, request, make_response, Response, send_from_directory
from flask_cors import CORS

from chat import chat, regenerate
from db_lib import get_db

app = Flask(__name__, static_url_path='', static_folder='build', template_folder='build')
CORS(app, supports_credentials=True)

# Check available models
models = [line.split(" ")[0].replace(":latest", "") for line in
          filter(lambda x: ":" in x, subprocess.run(["ollama", "list"], stdout=subprocess.PIPE).stdout.decode("utf-8").splitlines())]

# Initialise database on server start
cursor = sqlite3.connect("chatbot.db").cursor()
cursor.execute("""
    CREATE TABLE IF NOT EXISTS chat (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        owner TEXT NOT NULL,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )
""")
cursor.execute("""
    CREATE TABLE IF NOT EXISTS chat_message (
        id TEXT PRIMARY KEY,
        chat_id TEXT NOT NULL,
        content TEXT NOT NULL,
        model TEXT NOT NULL,
        type TEXT NOT NULL,
        response_to INTEGER,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )
""")
cursor.execute("""
    CREATE TABLE IF NOT EXISTS chat_message_summary (
        chat_id PRIMARY KEY,
        content TEXT NOT NULL,
        timestamp DATETIME NOT NULL
    )
""")
cursor.close()


@app.route("/api/chats", methods=["GET"])
def get_chats():
    db = get_db()
    chats = []
    identity_token = request.cookies.get("identity_token")

    # Existing user, retrieve chat list
    if identity_token:
        chats = db.execute("SELECT * FROM chat WHERE owner = ? ORDER BY timestamp DESC", [identity_token]).fetchall()

    response = make_response(chats)

    # Set cookie for new user
    if not identity_token:
        response.set_cookie("identity_token", uuid4().hex, max_age=36000)

    db.connection.close()
    return response


@app.route("/api/chat/<string:chat_id>", methods=["DELETE"])
def delete_chat(chat_id):
    db = get_db()
    identity_token = request.cookies.get("identity_token")

    # Delete chat if it belongs to user
    db.execute("DELETE FROM chat WHERE id = ? AND owner = ?", [chat_id, identity_token])

    if db.rowcount > 0:
        db.connection.commit()
        db.connection.close()
        return {"status": "success", "message": "Chat deleted successfully"}

    db.connection.close()
    return {"status": "failure", "message": "Invalid chat_id"}


@app.route("/api/chat/<string:chat_id>", methods=["GET"])
def get_chat_messages(chat_id):
    db = get_db()
    identity_token = request.cookies.get("identity_token")

    # Check if chat belongs to user
    count = db.execute("SELECT COUNT(id) FROM chat WHERE id = ? AND owner = ?", [chat_id, identity_token]).fetchone()["COUNT(id)"]
    if count == 0:
        db.connection.close()
        return {"status": "failure", "message": "Invalid chat_id"}

    # Get chat messages from chat
    chat_messages = db.execute("SELECT * FROM chat_message WHERE chat_id = ? ORDER BY timestamp", [chat_id]).fetchall()

    return {"status": "success", "chat_messages": chat_messages}


@app.route("/api/chat", methods=["POST"])
def send_chat_message():
    db = get_db()
    identity_token = request.cookies.get("identity_token")
    data = request.json
    chat_id = data["chat_id"]
    content = data["content"]
    model = data["model"]

    # Check if model is valid
    if model not in models:
        model = "llama3"

    # Check if chat belongs to user
    if chat_id:
        count = db.execute("SELECT COUNT(id) FROM chat WHERE id = ? AND owner = ?", [data["chat_id"], identity_token]).fetchone()["COUNT(id)"]
        if count == 0:
            db.connection.close()
            return {"status": "failure", "message": "Invalid chat_id"}

    return Response(chat(db, identity_token, content, chat_id, model), mimetype="text/event-stream")


@app.route("/api/chat_message/<string:chat_message_id>/regenerate", methods=["POST"])
def regenerate_chat_message(chat_message_id):
    db = get_db()
    identity_token = request.cookies.get("identity_token")
    data = request.json
    model = data["model"]

    # Check if model is valid
    if model not in models:
        model = "llama3"

    # Find original user message (also ensure that chat belongs to user)
    message = db.execute("""
        SELECT chat_id, content, m.id AS id, m.timestamp AS timestamp
        FROM chat_message m, chat c
        WHERE m.chat_id = c.id AND m.id = ? AND c.owner = ?
    """, [chat_message_id, identity_token]).fetchone()

    if not message:
        db.connection.close()
        return {"status": "failure", "message": "Invalid chat_message_id"}

    return Response(regenerate(db, message, model), mimetype="text/event-stream")


@app.route("/api/chat_message/<string:chat_message_id>", methods=["DELETE"])
def delete_chat_message(chat_message_id):
    db = get_db()
    identity_token = request.cookies.get("identity_token")

    # Check if chat message belongs to user
    count = db.execute("SELECT COUNT(m.id) FROM chat_message m, chat c WHERE m.chat_id = c.id AND m.id = ? AND c.owner = ?", [chat_message_id, identity_token]).fetchone()["COUNT(m.id)"]
    if count == 0:
        db.connection.close()
        return {"status": "failure", "message": "Invalid chat_message_id"}

    # Delete chat message
    db.execute("DELETE FROM chat_message WHERE id = ?", [chat_message_id])
    db.connection.commit()
    db.connection.close()
    return {"status": "success", "message": "Chat message deleted successfully"}


@app.route("/api/import", methods=["POST"])
def import_chat():
    db = get_db()
    identity_token = request.cookies.get("identity_token")
    data = request.json
    title = data["title"]
    messages = data["messages"]

    # Create a mapping of old message IDs to new message IDs
    id_mapping = {}

    # Create new chat ID
    chat_id = uuid4().hex
    # Insert new chat topic
    db.execute("INSERT INTO chat (id, title, owner) VALUES (?, ?, ?)", (chat_id, title, identity_token))

    for msg in messages:
        old_id = msg['id']  # Store the old message ID
        new_id = uuid4().hex  # Generate a new message ID

        # Map old ID to new ID
        id_mapping[old_id] = new_id
        
        # Replace the message ID with the new one
        msg['id'] = new_id

        # Check if the message has a 'response_to' field and update it if needed
        if msg.get('response_to'):
            msg['response_to'] = id_mapping.get(msg['response_to'], None)  # Replace the old 'response_to' ID with the new one
        
        response_to = msg.get('response_to')
        model = msg.get("model", "llama3")
        
        # Insert new chat messages
        db.execute("INSERT INTO chat_message (id, chat_id, content, model, type, response_to) VALUES (?, ?, ?, ?, ?, ?)", [msg['id'], chat_id, msg['content'], model, msg['type'], response_to])

    chat_messages = db.execute("SELECT * FROM chat_message WHERE chat_id = ?", [chat_id]).fetchall()
    response = [{
        "chatId": chat_id,
        "chatTitle": title
    }]
        
    db.connection.commit()
    db.connection.close()

    return response


@app.route("/api/available_models", methods=["GET"])
def get_available_models():
    return models


# Route to serve the React app (for client-side routing)
@app.route('/')
def serve():
    return send_from_directory(app.static_folder, 'index.html')


# Optional: Serve any other static file (like images, css, js, etc.)
@app.route('/static/<path:path>')
def static_files(path):
    return send_from_directory(app.static_folder + '/static', path)


# For React Router, catch-all routes that need to serve the React app
@app.route('/<string:path>')
def catch_all(path):
    if path.endswith((".ico", ".png", ".json", ".txt")):
        return send_from_directory(app.static_folder, path)
    return send_from_directory(app.static_folder, 'index.html')


if __name__ == '__main__':
    app.run()
