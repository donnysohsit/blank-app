from json import dumps
from uuid import uuid4
from langchain_core.documents import Document
from langchain_core.prompts import PromptTemplate
from langchain_ollama import OllamaEmbeddings
from summarisation import *

prompt_template = """
<|begin_of_text|><|start_header_id|>system<|end_header_id|>
You are a helpful and professional AI assistant that specializes in Data Structure and Algorithm (DSA) related questions. 
You can assist users of all knowledge levels, from beginners to advanced.
Keep your answers brief, concise, and approachable while remaining professional. 
Always ensure that the answer is accurate and, when necessary, provide warnings about potential risks or common misunderstandings.
Your scope is strictly limited to DSA-related questions, and you should refrain from answering queries outside this domain.
{summary}
{relevant_history}
{recent_history}
The user input is as follows:
{user_message}
"""






prompt_template_title = """
<|begin_of_text|><|start_header_id|>system<|end_header_id|>

Please generate a short title for this user message. Only output the title without any punctuation.
User: {user_message}<|eot_id|>
"""


def get_vector_store(chat_id):
    embeddings = OllamaEmbeddings(model="llama3")
    return Chroma(
        collection_name=chat_id,
        embedding_function=embeddings,
        persist_directory=f"vector_store/{chat_id}",
        collection_metadata={"hnsw:space": "cosine"}
    )


def get_chat_history(db, vector_store: Chroma, chat_id, user_message, up_to=None):

    # Get all chat messages
    if not up_to:
        chat_messages = db.execute("SELECT * FROM chat_message WHERE chat_id = ? AND type != 'ai-regen' ORDER BY timestamp, type DESC", [chat_id]).fetchall()
    else:
        chat_messages = db.execute("SELECT * FROM chat_message WHERE chat_id = ? AND type != 'ai-regen' AND timestamp < ? ORDER BY timestamp, type DESC", [chat_id, up_to]).fetchall()

    # Get recent messages
    recent_messages = chat_messages[-5:]
    recent_history = "Latest 5 chat messages:\n" + \
        "\n".join([f"{'User' if message.get('type') == 'user' else 'Assistant'}: {message.get('content')}" for message in recent_messages]) + \
        "\n"

    # Skip RAG if history length <= 5
    if len(chat_messages) <= 5:
        return "", recent_history

    # Get relevant messages
    retriever = vector_store.as_retriever(
        search_type="similarity_score_threshold",
        search_kwargs={"score_threshold": 0.5, "k": 5}
    )
    relevant_message_documents = retriever.invoke(user_message)
    relevant_message_ids = [document.metadata.get("id") for document in relevant_message_documents]
    recent_message_ids = [message.get("id") for message in recent_messages]
    relevant_messages = [message for message in chat_messages if message.get("id") in relevant_message_ids and message.get("id") not in recent_message_ids]
    relevant_history = "Relevant chat messages:\n" + \
        "\n".join([f"{'User' if message.get('type') == 'user' else 'Assistant'}: {message.get('content')}" for message in relevant_messages]) + \
        "\n"

    return relevant_history, recent_history


def generate_title(llm, user_message):
    prompt = PromptTemplate.from_template(prompt_template_title).format(
        user_message=user_message
    )
    return llm.invoke(prompt)


def insert_chat(db, chat_id, title, owner):
    db.execute("INSERT INTO chat(id, title, owner) VALUES (?, ?, ?)", [chat_id, title, owner])
    db.connection.commit()


def insert_chat_message(db, chat_id, content, model, message_type, response_to):
    chat_message_id = uuid4().hex
    db.execute(
        "INSERT INTO chat_message(id, chat_id, content, model, type, response_to) VALUES (?, ?, ?, ?, ?, ?)",
        [chat_message_id, chat_id, content, model, message_type, response_to]
    )
    db.connection.commit()
    return chat_message_id


def update_vector_store(vector_store: Chroma, user_message_id, user_message, ai_message_id, ai_message):
    user_document = Document(page_content=user_message, metadata={"id": user_message_id, "type": "user"})
    ai_document = Document(page_content=ai_message, metadata={"id": ai_message_id, "type": "ai"})
    vector_store.add_documents([user_document, ai_document])


def chat(db, identity_token, user_message, chat_id, model):

    # Generate chat_id for new chat
    new_chat = False if chat_id else True
    if new_chat:
        chat_id = uuid4().hex
        yield dumps({"event_type": "chat_id", "data": chat_id})

    # Connect to vector store
    vector_store = get_vector_store(chat_id)

    # Get chat history
    relevant_history, recent_history = ("", "") if new_chat else get_chat_history(db, vector_store, chat_id, user_message)

    # Get existing summary, if any:
    summary, summary_timestamp = get_chat_summary(db, chat_id)

    # Generate prompt
    prompt = PromptTemplate.from_template(prompt_template).format(
        summary=summary,
        relevant_history=relevant_history,
        recent_history=recent_history,
        user_message=user_message
    )

    print("===== PROMPT =====")
    print(prompt)
    print("----- PROMPT -----")

    # Talk to llm
    llm = OllamaLLM(model=model)
    response = []
    print("===== RESPONSE =====")
    for chunk in llm.stream(prompt):
        response.append(chunk)
        print(chunk, end="")
        yield dumps({"event_type": "response", "data": chunk})
    ai_message = "".join(response)
    print("\n----- RESPONSE -----")

    # Insert new chat
    if new_chat:
        title = generate_title(llm, user_message)
        insert_chat(db, chat_id, title, identity_token)
        yield dumps({"event_type": "title", "data": title})

    # Insert chat messages into db
    user_message_id = insert_chat_message(db, chat_id, user_message, model, "user", None)
    ai_message_id = insert_chat_message(db, chat_id, ai_message, model, "ai", user_message_id)
    yield dumps({"event_type": "user_message_id", "data": user_message_id})
    yield dumps({"event_type": "ai_message_id", "data": ai_message_id})
    
    # Check the number of messages not yet summarised, and perform summarisation if greater than 10
    if summary_timestamp:
        count = db.execute("SELECT COUNT(id) AS count FROM chat_message WHERE chat_id = ? AND type != 'ai-regen' AND timestamp > ?", [chat_id, summary_timestamp]).fetchone()["count"]
    else:
        count = db.execute("SELECT COUNT(id) AS count FROM chat_message WHERE chat_id = ? AND type != 'ai-regen'", [chat_id]).fetchone()["count"]
    print(f"[Summary] There are {count} messages not yet summarised")
    if count >= 10:
        begin_chat_summarisation(chat_id)

    # Update vector store with new messages
    print(f"[RAG] Updating vector store")
    update_vector_store(vector_store, user_message_id, user_message, ai_message_id, ai_message)
    print(f"[RAG] Vector store updated")


def regenerate(db, message, model):
    chat_id = message.get("chat_id")
    user_message = message.get("content")
    user_message_id = message.get("id")
    timestamp = message.get("timestamp")
    print(message)

    # Connect to vector store
    vector_store = get_vector_store(message.get("chat_id"))

    # Get chat history
    relevant_history, recent_history = get_chat_history(db, vector_store, chat_id, user_message, timestamp)

    # Generate prompt
    prompt = PromptTemplate.from_template(prompt_template).format(
        relevant_history=relevant_history,
        recent_history=recent_history,
        user_message=user_message
    )
    print("===== PROMPT =====")
    print(prompt)
    print("----- PROMPT -----")

    # Talk to llm
    llm = OllamaLLM(model=model)
    response = []
    print("===== RESPONSE =====")
    for chunk in llm.stream(prompt):
        response.append(chunk)
        print(chunk, end="")
        yield dumps({"event_type": "response", "data": chunk})
    ai_message = "".join(response)
    print("\n----- RESPONSE -----")

    # Insert regenerated message to db
    ai_message_id = insert_chat_message(db, chat_id, ai_message, model, "ai-regen", user_message_id)
    yield dumps({"event_type": "ai_message_id", "data": ai_message_id})



