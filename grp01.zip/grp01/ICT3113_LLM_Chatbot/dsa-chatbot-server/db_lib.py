import sqlite3


def dict_factory(cur, row):
    return {col[0]: row[_] for _, col in enumerate(cur.description)}


def get_db():
    connection = sqlite3.connect("chatbot.db")
    connection.row_factory = dict_factory
    return connection.cursor()