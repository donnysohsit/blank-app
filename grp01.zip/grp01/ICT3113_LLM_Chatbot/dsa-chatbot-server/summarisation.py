import threading
from langchain_chroma import Chroma
from langchain_community.embeddings import OllamaEmbeddings
from langchain_ollama import OllamaLLM

from db_lib import dict_factory, get_db

mutex = threading.Lock()
summarising = []  # chat_ids of chats being summarised
summary_queue = []  # Queue up

prompt_template_chat_summary = """
<|begin_of_text|><|start_header_id|>system<|end_header_id|>
You are a helpful and professional AI assistant that specialises in summarising chat history related to Data Structure and Algorithm (DSA) conversations. 
Your summaries will be used for Large Language Models, to add them in providing contextualized questions for the user.
Your summaries should sufficiently cover the relevant context required, but should not exceed 200 words.
Always ensure that your summaries are accurate.
"""
prompt_template_chat_summary_end = "<|begin_of_text|><|start_header_id|>Assistant<|end_header_id|>"


def summarise_chat_history(chat_id):
    """_summary_
    A chat history that is too long will slow down response generation.
    
    Hence, for every 10 or more messages, we will ask the llm to generate a summary of these chat messages.
    """

    prompt = prompt_template_chat_summary

    llm = OllamaLLM(model="llama3")
    db = get_db()
    existing_summary = db.execute("SELECT * FROM chat_message_summary WHERE chat_id = ?", [chat_id]).fetchall()

    if len(existing_summary):
        prompt += "An existing summary of older chat history is as follows. You are to incorporate them in your summaries as well.:"
        prompt += existing_summary[-1]["content"]
        prompt += "\n"
        chat_messages = db.execute("SELECT * FROM chat_message WHERE chat_id = ? AND type != 'ai-regen' AND timestamp > ?",
                                   [chat_id, existing_summary[-1]["timestamp"]]).fetchall()
    else:
        chat_messages = db.execute("SELECT * FROM chat_message WHERE chat_id = ? AND type != 'ai-regen' ORDER BY timestamp", [chat_id]).fetchall()

    chat_messages = chat_messages[-10:]  # Only summarise the last 10
    if len(chat_messages) < 10:  # Terminate early, no need to summarise
        summarising.remove(chat_id)
        if len(summary_queue):
            next_chat_id = summary_queue[0]
            summarising.append(next_chat_id)
            summary_queue.pop(0)
            summarise_chat_history(next_chat_id)
            return
    if len(existing_summary):
        prompt += "The latest chat history is as follows:"
    else:
        prompt += "The chat history is as follows:"

    for message in chat_messages:
        prompt += f"{'User' if message['type'] == 'user' else 'AI'}: {message['content']}\n"
    prompt += prompt_template_chat_summary_end

    print("===== Summary Prompt ======")
    print(prompt)
    print("----- Summary Prompt -----")

    print("===== Summary Response =====")
    new_summary = llm.invoke(prompt)
    print(new_summary)
    print("===== Summary Response =====")

    if len(existing_summary):
        db.execute("UPDATE chat_message_summary SET content = ?, timestamp = ? WHERE chat_id = ?",
                   [new_summary, chat_messages[-1]["timestamp"], chat_id])
    else:
        db.execute("INSERT INTO chat_message_summary (chat_id, content, timestamp) VALUES (?, ?, ?)",
                   [chat_id, new_summary, chat_messages[-1]["timestamp"]])

    db.connection.commit()
    db.connection.close()

    summarising.remove(chat_id)

    print("[Summarising] Summary generation complete for", chat_id)
    if len(summary_queue):
        next_chat_id = summary_queue[0]
        summarising.append(next_chat_id)
        summary_queue.pop(0)
        summarise_chat_history(next_chat_id)


def begin_chat_summarisation(chat_id):
    with mutex:
        if len(summarising):  # Something is being processed atm
            if chat_id not in summary_queue and chat_id not in summarising:  # If this chat is not being processed
                summary_queue.append(chat_id)
        # If nothing is being processed atm
        elif chat_id not in summary_queue:  # If it is not queued for summarisation
            summarising.append(chat_id)
            print("[Summarising] Beginning summary thread for", chat_id)
            thr = threading.Thread(target=summarise_chat_history, args=[chat_id])
            thr.start()


def get_chat_summary(db, chat_id):
    """
    Returns the existing summary of chat history and the timestamp of the last chat message summarised.
    Returns None, None if no summary exists
    """
    summary = db.execute("SELECT * FROM chat_message_summary WHERE chat_id = ?", [chat_id]).fetchone()

    if summary:
        return f"The following is a short summary of the conversation:\n{summary['content']}", summary["timestamp"]

    return "", None
